package com.ledgerx.core.domain;

public enum RefundAction {
    RETRY_NOW,
    WAIT,
    ESCALATE
}