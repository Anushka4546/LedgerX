package com.ledgerx.core.domain;

public enum EvidenceSource {
    GATEWAY,
    BANK,
    LEDGER,
    OPS
}
